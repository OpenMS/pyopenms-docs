# README
- Alles nötige wird erstellt um aus unserem Projekt ein Python wheel zu generieren.
- Anleitung : https://packaging.python.org/tutorials/packaging-projects/

